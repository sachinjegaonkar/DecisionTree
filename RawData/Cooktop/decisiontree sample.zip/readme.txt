
XML/XSL based Decision Tree Analysis Tool
Version 0.1

Get latest info regarding this tool at http://www.sabufrancis.com/decisiontree

You may need to wordwrap this file to see the lines here properly


How to use the XML/XSL based decision tree analysis?

Extract this zip file to a folder 
Download a suitable XSLT processor (MSXSL can be downloaded from the MSDN site There are other XSLT processors too. Google for them!) 
Open a console window on your computer (Run "cmd" in Windows 2000 or XP) 
Change directory to the folder where you've extracted the two files from the ZIP file 
Run the XSLT processor so that the XSL does its magic on the XML file 

... or a simpler method:

Download cooktop from http://www.xmlcooktop.com and install it 
Load the XML file and XSL file into cooktop 
Press F5 
Enjoy looking at the results (Look at the plain text results. The HTML result may look unformatted)


If you use the cooktop method, and if you can be bold enough to modify the XML file to suit your own decision trees, then you can easily use it as an environment to analyse your own decisions.

Note: There are several downside to a decision making tool such as a Decision tree. The most glaring of them is that the accuracy of the decision tree depends on predicting the returns on outcomes and the value of the probability of reaching those outcomes. So don't trust the tool blindly. Spend quite some time thinking about the values you want to enter

In short, get your fundamentals straightened out regarding decision tree. A good starting point is:

http://www.mindtools.com/pages/article/newTED_04.htm

There are many other good starting points too. Google or Wikipedia would be nice places to start with

Sabu Francis
Sept 16, 2005

This utility is licensed under GPL (Not included here for brevity. See the license at http://www.gnu.org/copyleft/gpl.html )




