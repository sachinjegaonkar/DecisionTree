using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using DSO;

namespace RefreshSalesCube
{
	/// <summary>
	/// Summary description for RefreshSalesCube.
	/// </summary>
	class RefreshSalesCube
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			try
			{
				Console.WriteLine("Processing cube Sales...");
				DSO.ServerClass dsoServer = new ServerClass();
				dsoServer.Connect("localhost");

				DSO.OlapCollection coll = (DSO.OlapCollection)dsoServer.MDStores;
				DSO.Database dsoDB = (DSO.Database)coll.Item("TREE_DB");
	
				coll = (DSO.OlapCollection)dsoDB.MDStores;
				DSO.Cube dsoCube = (DSO.Cube)coll.Item("Sales");
	
				coll = (DSO.OlapCollection)dsoDB.Dimensions;
				DSO.Dimension dsoDim = (DSO.Dimension)coll.Item("TREE_OLAP");
				DSO.Dimension dsoTimeDim = (DSO.Dimension)coll.Item("TIME");

				dsoCube.Dimensions.Remove(dsoDim.Name);

				int i = dsoDim.Levels.Count;
				while(i > 0)
				{
					dsoDim.Levels.Remove(i);
					i--;
				}

				SqlConnection cnn = new SqlConnection(ConfigurationSettings.AppSettings["ConnectionString"]);
				cnn.Open();

				SqlDataAdapter da = new SqlDataAdapter("SELECT TOP 0 * FROM TREE_OLAP", cnn);
				DataTable dt = new DataTable();
				da.Fill(dt);
				cnn.Close();

				int nColumns = dt.Columns.Count;
				int adVarChar = 200;
				for(i = 1; i < nColumns; i++)
				{
					DSO.Level lvl = (DSO.Level)dsoDim.Levels.AddNew(dt.Columns[i].ColumnName, DSO.SubClassTypes.sbclsRegular);
					lvl.MemberKeyColumn = "\"dbo\".\"TREE_OLAP\".\"" + dt.Columns[i].ColumnName + "\"";
					lvl.ColumnType = (short)adVarChar;
					lvl.ColumnSize = 100;
				}
				dsoDim.Process(DSO.ProcessTypes.processFull);

				/*
				object o = dsoCube.Dimensions.Count - 1;
				dsoCube.Dimensions.Add(dsoDim, "TREE_OLAP", o); // error "Type mismatch" at "Before" parameter
				*/

				DSO.Dimension dim = (DSO.Dimension)dsoCube.Dimensions.AddNew("TREE_OLAP", DSO.SubClassTypes.sbclsRegular);
				dim = dsoDim;

				dsoCube.JoinClause = "\"dbo\".\"Sales\".\"TREE_ID\" = \"dbo\".\"TREE_OLAP\".\"ID\" AND \"dbo\".\"Sales\".\"TIME_ID\" = \"dbo\".\"TIME_BY_DAY\".\"ID\"";

				dsoCube.Update();

				dsoCube.Process(DSO.ProcessTypes.processFull);

				dsoServer.CloseServer();

				Console.WriteLine("Sales cube was processed successfully!");
				Console.ReadLine();
			}
			catch(Exception ex)
			{
				while(ex != null)
				{
					Console.WriteLine(ex.Message);
					ex = ex.InnerException;
				}
			}
		}
	}
}
