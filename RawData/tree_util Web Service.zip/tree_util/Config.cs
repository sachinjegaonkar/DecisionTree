using System;
using System.Configuration;

namespace tree_util
{
	/// <summary>
	/// Summary description for Config.
	/// </summary>
	public class Config
	{
		public Config()
		{
		}

		public static string ConnectionString = ConfigurationSettings.AppSettings["ConnectionString"];
	}
}
