using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Web;
using System.Web.Services;
using System.Xml;
using System.Xml.Xsl;
using System.Xml.XPath;
using System.IO;
using System.Net;
using System.Data.SqlClient;

namespace tree_util
{
	/// <summary>
	/// Summary description for index.
	/// </summary>
	public class index : System.Web.Services.WebService
	{
		public index()
		{
			//CODEGEN: This call is required by the ASP.NET Web Services Designer
			InitializeComponent();

		}

		#region Component Designer generated code
		
		//Required by the Web Services Designer 
		private IContainer components = null;
				
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if(disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);		
		}
		
		#endregion


		[WebMethod]
		public XmlDocument GetDirectTree(int RootID)
		{
			XmlDocument xmldoc = new XmlDocument();
			string strXML;
			try
			{
				SqlConnection cnn = new SqlConnection(Config.ConnectionString);
				cnn.Open();
				SqlCommand cmd = new SqlCommand("TREE_GET_XML", cnn);
				cmd.CommandType = CommandType.StoredProcedure;
				SqlParameter param = new SqlParameter("@ROOT_ID", typeof(int));
				param.Value = RootID;
				cmd.Parameters.Add(param);
				XmlReader rdr = cmd.ExecuteXmlReader();
				rdr.Read();
				strXML = rdr.ReadOuterXml();
				if(strXML != string.Empty)
					xmldoc.LoadXml(strXML);
				else
					xmldoc.LoadXml("<root></root>");
			}
			catch(Exception ex)
			{
				strXML = "<errors>";
				while(ex != null)
				{
					strXML += "<error>";
					strXML += ex.Message;
					strXML += "</error>";
					ex = ex.InnerException;
				}
				strXML += "</errors>";
				xmldoc.LoadXml(strXML);
			}
			return xmldoc;
		}

		[WebMethod]
		public XmlDocument GetStructuredTree(int RootID)
		{
			XmlDocument xmldoc = new XmlDocument();
			string strXML;
			try
			{
				xmldoc = GetDirectTree(RootID);
				strXML = Transform(xmldoc);
				xmldoc.LoadXml(strXML);
			}
			catch(Exception ex)
			{
				strXML = "<errors>";
				while(ex != null)
				{
					strXML += "<error>";
					strXML += ex.Message;
					strXML += "</error>";
					ex = ex.InnerException;
				}
				strXML += "</errors>";
				xmldoc.LoadXml(strXML);
			}
			return xmldoc;
		}

		private string Transform(XmlDocument xmldoc)
		{
			string strXML = string.Empty;
			try
			{
				string xslTemplatePath = Server.MapPath("") + "\\tree.xsl";
				XPathNavigator nav = xmldoc.DocumentElement.CreateNavigator();

				XmlDocument xsldoc = new XmlDocument();
				xsldoc.Load(xslTemplatePath);
				XmlNamespaceManager nsmgr = new XmlNamespaceManager(xsldoc.NameTable);
				nsmgr.AddNamespace("xsl", "http://www.w3.org/1999/XSL/Transform");

				XmlUrlResolver resolver = new XmlUrlResolver();
				XslTransform trans = new XslTransform();
				trans.Load(xsldoc, resolver, this.GetType().Assembly.Evidence);

				TextWriter writer = new StringWriter();

				XmlTextWriter xmlWriter = new XmlTextWriter(writer);
				xmlWriter.Formatting = Formatting.Indented;

				trans.Transform(nav, null, xmlWriter, null);

				strXML = writer.ToString();
			}
			catch(Exception ex)
			{
				strXML = "<errors>";
				while(ex != null)
				{
					strXML += "<error>";
					strXML += ex.Message;
					strXML += "</error>";
					ex = ex.InnerException;
				}
				strXML += "</errors>";
			}
			return strXML;
		}

	}
}
